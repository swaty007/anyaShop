<?php

define('WCFMmp_TOKEN', 'wcfmmp');

define('WCFMmp_TEXT_DOMAIN', 'wc-multivendor-marketplace');

define('WCFMmp_VERSION', '3.4.7');

define('WCFMmp_SERVER_URL', 'https://wclovers.com');

?>